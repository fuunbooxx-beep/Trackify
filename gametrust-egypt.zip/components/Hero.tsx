"use client";

import { Search, ShieldAlert, ArrowLeft } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function Hero() {
  const [query, setQuery] = useState("");
  const router = useRouter();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden flex flex-col items-center justify-center min-h-[80vh]">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background z-0" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-destructive/10 text-destructive dark:bg-destructive/20 mb-6 border border-destructive/20 font-semibold text-sm mr-auto ml-auto">
            <ShieldAlert className="w-4 h-4" />
            <span>معاً ضد النصب في منتدى الجيمنج المصري</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-black mb-6 leading-tight select-none">
            إفحص <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-500 dark:from-neon-blue dark:to-neon-purple">البائعين والصفحات</span><br/>
            قبل ما تشتري الداتا أو الحسابات
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto font-medium">
            ابحث برقم الفون، لينك الصفحة، أو الإسم وشوف مستوى الثقة وتجارب الناس التانية معاه.
          </p>

          <form onSubmit={handleSearch} className="relative max-w-2xl mx-auto group">
            <div className="absolute -inset-1 bg-gradient-to-r from-primary to-blue-500 dark:from-neon-blue dark:to-neon-purple rounded-full blur opacity-25 group-hover:opacity-50 transition duration-500"></div>
            <div className="relative flex items-center bg-card rounded-full p-2 border border-border shadow-xl">
              <input 
                type="text" 
                placeholder="رقم الفون مثلا: 01000000000 أو لينك الصفحة..."
                className="flex-1 bg-transparent border-none outline-none px-6 text-foreground placeholder:text-muted-foreground rtl:text-right"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <button 
                type="submit"
                className="bg-primary dark:bg-neon-blue hover:scale-105 transition-transform text-white dark:text-black w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
              >
                <Search className="w-5 h-5 ltr-icon" />
              </button>
            </div>
          </form>

          <div className="mt-8 flex flex-wrap justify-center gap-4 text-sm text-muted-foreground font-medium">
            <span>عمليات بحث شائعة:</span>
            <span className="hover:text-primary dark:hover:text-neon-blue cursor-pointer transition-colors bg-secondary/50 px-2 py-0.5 rounded-md">حسابات ببجي</span>
            <span className="hover:text-primary dark:hover:text-neon-blue cursor-pointer transition-colors bg-secondary/50 px-2 py-0.5 rounded-md">شحن شدات</span>
            <span className="hover:text-primary dark:hover:text-neon-blue cursor-pointer transition-colors bg-secondary/50 px-2 py-0.5 rounded-md">فالورانت بوينتس</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
