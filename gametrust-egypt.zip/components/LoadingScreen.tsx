"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield } from "lucide-react";

export function LoadingScreen() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate initial loading sequence
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.1 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col items-center"
          >
            <div className="relative mb-6">
              <Shield className="w-20 h-20 text-neon-blue" />
              <motion.div
                className="absolute inset-0 border-t-2 border-neon-blue rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
              />
              <motion.div
                className="absolute inset-2 border-b-2 border-neon-purple rounded-full"
                animate={{ rotate: -360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              />
            </div>
            
            <h1 className="text-2xl font-bold font-inter tracking-wider uppercase bg-clip-text text-transparent bg-gradient-to-r from-neon-blue to-neon-purple">
              GameTrust Egypt
            </h1>
            <p className="mt-2 text-muted-foreground font-cairo">جاري فحص قاعدة البيانات...</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
