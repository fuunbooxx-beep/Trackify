"use client";

import { Shield, Moon, Sun, Menu, X, User as UserIcon } from "lucide-react";
import { useTheme } from "next-themes";
import { useState, useContext, useEffect } from "react";
import { AuthContext } from "@/lib/providers";
import { GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import Link from "next/link";
import { motion } from "motion/react";

export function Navbar() {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const { user, loading } = useContext(AuthContext);
  const [mounted, setMounted] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => setMounted(true), []);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = () => signOut(auth);

  return (
    <nav className="fixed top-0 w-full z-50 glass-panel border-b border-white/10 dark:border-white/5 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="relative">
              <Shield className="w-8 h-8 text-primary dark:text-neon-blue transition-transform group-hover:scale-110 duration-300" />
              <div className="absolute inset-0 bg-primary/20 dark:bg-neon-blue/20 blur-lg rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <span className="font-bold text-xl tracking-tight hidden sm:block bg-clip-text text-transparent bg-gradient-to-l from-foreground to-foreground/70">
              GameTrust Egypt
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <NavLink href="/" text="الرئيسية" />
            <NavLink href="/report" text="تقديم بلاغ" />
            <NavLink href="/trending" text="الأكثر بلاغاً" />
            <NavLink href="/about" text="عن المنصة" />
          </div>

          <div className="flex items-center gap-3">
            {mounted && (
              <button
                onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                className="p-2 rounded-full hover:bg-secondary/80 transition-colors relative"
                aria-label="Toggle theme"
              >
                {resolvedTheme === "dark" ? (
                  <Sun className="w-5 h-5 text-yellow-500" />
                ) : (
                  <Moon className="w-5 h-5 text-slate-700" />
                )}
              </button>
            )}

            {!loading && user ? (
              <div className="flex items-center gap-2">
                <Link href="/profile" className="hidden sm:flex items-center gap-2 hover:bg-secondary/80 py-1.5 px-3 rounded-full transition-colors">
                  <span className="text-sm font-medium">{user.displayName?.split(" ")[0]}</span>
                  <img src={user.photoURL || ""} alt="Avatar" className="w-7 h-7 rounded-full border border-border" />
                </Link>
                <button 
                  onClick={handleLogout}
                  className="text-sm font-medium text-destructive hover:bg-destructive/10 px-3 py-1.5 rounded-full transition-colors"
                >
                  خروج
                </button>
              </div>
            ) : (
              <button onClick={handleLogin} className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2 rounded-full text-sm font-bold transition-all shadow-[0_0_15px_rgba(37,99,235,0.3)] dark:shadow-[0_0_15px_rgba(0,243,255,0.3)] dark:bg-neon-blue dark:text-black">
                <UserIcon className="w-4 h-4" />
                <span>تسجيل الدخول</span>
              </button>
            )}

            {/* Mobile menu button */}
            <button 
              className="md:hidden p-2 text-foreground"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden glass-panel border-b border-border absolute w-full"
        >
          <div className="px-4 pt-2 pb-6 space-y-3 flex flex-col">
            <MobileNavLink href="/" text="الرئيسية" onClick={() => setMobileMenuOpen(false)} />
            <MobileNavLink href="/report" text="تقديم بلاغ" onClick={() => setMobileMenuOpen(false)} />
            <MobileNavLink href="/trending" text="الأكثر بلاغاً" onClick={() => setMobileMenuOpen(false)} />
            <MobileNavLink href="/profile" text="حسابي" onClick={() => setMobileMenuOpen(false)} />
          </div>
        </motion.div>
      )}
    </nav>
  );
}

function NavLink({ href, text }: { href: string; text: string }) {
  return (
    <Link href={href} className="text-sm font-semibold text-foreground/80 hover:text-primary dark:hover:text-neon-blue transition-colors relative group">
      {text}
      <span className="absolute -bottom-1 right-0 w-0 h-0.5 bg-primary dark:bg-neon-blue transition-all group-hover:w-full"></span>
    </Link>
  );
}

function MobileNavLink({ href, text, onClick }: { href: string; text: string; onClick: () => void }) {
  return (
    <Link href={href} onClick={onClick} className="block px-3 py-2 text-base font-semibold rounded-md hover:bg-secondary">
      {text}
    </Link>
  );
}
