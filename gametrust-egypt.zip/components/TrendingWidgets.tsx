"use client";

import { useEffect, useState } from "react";
import { collection, query, where, orderBy, limit, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";
import Link from "next/link";
import { AlertTriangle, ShieldCheck } from "lucide-react";

export function TopAlerts() {
  const [targets, setTargets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrending = async () => {
      try {
        const q = query(collection(db, "targets"), where("status", "==", "high_risk"), limit(5));
        const snapshot = await getDocs(q);
        // Using local sort by reportCount since composite index might not exist yet
        setTargets(snapshot.docs.map(d => ({id: d.id, ...d.data()})).sort((a:any,b:any) => b.reportCount - a.reportCount));
      } catch(e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchTrending();
  }, []);

  if (loading) return <div>تحميل...</div>;
  if (!targets.length) return <div className="text-muted-foreground">مفيش بيانات</div>;

  return (
    <div className="space-y-4">
      {targets.map(t => (
        <Link href={`/target/${t.id}`} key={t.id} className="block group">
          <div className="glass-panel p-4 rounded-2xl border-l-4 border-l-destructive hover:bg-destructive/5 transition-colors flex justify-between items-center">
            <div>
              <div className="font-bold flex items-center gap-2 group-hover:text-destructive transition-colors">
                <AlertTriangle className="w-4 h-4 text-destructive" />
                {t.name}
              </div>
              <div className="text-sm text-muted-foreground mt-1">({t.reportCount}) بلاغات نصب</div>
            </div>
            <div className="text-xl font-black text-destructive">{t.trustScore}%</div>
          </div>
        </Link>
      ))}
    </div>
  );
}

export function TopSafePage() {
  const [targets, setTargets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrending = async () => {
      try {
        const q = query(collection(db, "targets"), where("status", "==", "trusted"), limit(5));
        const snapshot = await getDocs(q);
        setTargets(snapshot.docs.map(d => ({id: d.id, ...d.data()})).sort((a:any,b:any) => b.trustScore - a.trustScore));
      } catch(e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchTrending();
  }, []);

  if (loading) return <div>تحميل...</div>;
  if (!targets.length) return <div className="text-muted-foreground">مفيش بيانات</div>;

  return (
    <div className="space-y-4">
      {targets.map(t => (
        <Link href={`/target/${t.id}`} key={t.id} className="block group">
          <div className="glass-panel p-4 rounded-2xl border-l-4 border-l-green-500 hover:bg-green-500/5 transition-colors flex justify-between items-center">
            <div>
              <div className="font-bold flex items-center gap-2 group-hover:text-green-500 transition-colors">
                <ShieldCheck className="w-4 h-4 text-green-500" />
                {t.name}
              </div>
              <div className="text-sm text-muted-foreground mt-1">بائع موثوق</div>
            </div>
            <div className="text-xl font-black text-green-500">{t.trustScore}%</div>
          </div>
        </Link>
      ))}
    </div>
  );
}
