"use client";

import { Navbar } from "@/components/Navbar";
import { TopAlerts, TopSafePage } from "@/components/TrendingWidgets";

export default function TrendingPage() {
  return (
    <>
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-32 min-h-screen">
        <div className="mb-12 text-center max-w-2xl mx-auto">
          <h1 className="text-3xl md:text-5xl font-black mb-4">تريند النصب والأمان</h1>
          <p className="text-muted-foreground font-medium text-lg">
            أكتر الصفحات اللي عليها بلاغات نصب حالياً في مصر، وأكتر الصفحات الآمنة اللي المشتريين بينصحوا بيهم.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Top Scammers */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <span className="w-4 h-4 rounded-full bg-destructive animate-pulse"></span>
              <h2 className="text-2xl font-bold">أخطر صفحات حالياً</h2>
            </div>
            <TopAlerts />
          </div>

          {/* Top Safe */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <span className="w-4 h-4 rounded-full bg-green-500"></span>
              <h2 className="text-2xl font-bold">بائعين موثوقين</h2>
            </div>
            <TopSafePage />
          </div>
        </div>
      </div>
    </>
  );
}
