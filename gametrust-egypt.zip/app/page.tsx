"use client";

import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Particles } from "@/components/Particles";
import { LoadingScreen } from "@/components/LoadingScreen";
import { ShieldCheck, AlertTriangle, Users } from "lucide-react";

export default function Home() {
  return (
    <>
      <LoadingScreen />
      <Particles />
      <Navbar />
      
      <main className="flex-1">
        <Hero />
        
        {/* Quick Stats Section */}
        <section className="py-16 bg-secondary/30 border-y border-border/50 relative overflow-hidden">
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-primary/5 dark:bg-neon-blue/5 rounded-full blur-3xl" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <StatCard 
                icon={<ShieldCheck className="w-12 h-12 text-green-500" />}
                number="5,204"
                label="بائع موثوق"
                glowClass="glow-secure"
              />
              <StatCard 
                icon={<AlertTriangle className="w-12 h-12 text-red-500" />}
                number="1,842"
                label="نصاب تم كشفه"
                glowClass="glow-warning"
              />
              <StatCard 
                icon={<Users className="w-12 h-12 text-primary dark:text-neon-blue" />}
                number="32,000+"
                label="مستخدم نشط"
                glowClass="dark:glow-neon shadow-[0_0_15px_rgba(37,99,235,0.2)]"
              />
            </div>
          </div>
        </section>

        {/* Info Section */}
        <section className="py-24 max-w-5xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">ليه تستخدم <span className="text-primary dark:text-neon-blue">GameTrust</span>؟</h2>
            <p className="text-muted-foreground text-xl max-w-2xl mx-auto font-medium">
              مجتمع الجيمنج في مصر كبير، وللأسف عمليات النصب بتزيد. إحنا هنا علشان نحمي فلوسك وحساباتك.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            <div className="glass-panel p-8 rounded-[32px] relative overflow-hidden group hover:border-primary/50 dark:hover:border-neon-blue/50 transition-colors">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 dark:bg-neon-blue/10 rounded-bl-full -mr-16 -mt-16 transition-transform group-hover:scale-125" />
              <h3 className="text-2xl font-bold mb-4 flex items-center gap-3">
                <span className="bg-primary text-white dark:bg-neon-blue dark:text-black w-10 h-10 rounded-xl flex items-center justify-center font-black text-xl shadow-lg">1</span>
                <span>بحث سريع قبل الشراء</span>
              </h3>
              <p className="text-muted-foreground leading-relaxed text-lg font-medium">
                قبل ما تحول مليم لأي صفحة أو بائع، خد رقم الفون أو لينك الصفحة واعمل سيرش عندنا. هتشوف تقييم البائع وتجارب الناس بناءً على أدلة حقيقية.
              </p>
            </div>

            <div className="glass-panel p-8 rounded-[32px] relative overflow-hidden group hover:border-destructive/50 transition-colors">
              <div className="absolute top-0 left-0 w-32 h-32 bg-destructive/10 rounded-br-full -ml-16 -mt-16 transition-transform group-hover:scale-125" />
              <h3 className="text-2xl font-bold mb-4 flex items-center gap-3">
                <span className="bg-destructive text-white w-10 h-10 rounded-xl flex items-center justify-center font-black text-xl shadow-lg">2</span>
                <span>تقديم بلاغات موثقة</span>
              </h3>
              <p className="text-muted-foreground leading-relaxed text-lg font-medium">
                اتعرضت لنصب أو معاملة سيئة؟ قدم بلاغ وارفع السكرين شوتس كإثبات. البلاغ بتاعك هيحمي غيرك وهيأثر على الثقة (Trust Score) بتاع الصفحة دي.
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border mt-auto py-10 bg-secondary/20 relative">
        <div className="max-w-7xl mx-auto px-4 text-center text-muted-foreground font-medium flex flex-col items-center gap-4">
          <div className="font-bold text-2xl tracking-tight bg-clip-text text-transparent bg-gradient-to-l from-foreground to-foreground/60 mb-2">
            GameTrust Egypt
          </div>
          <p>© {new Date().getFullYear()} مجتمع جيمنج آمن للجميع.</p>
        </div>
      </footer>
    </>
  );
}

function StatCard({ icon, number, label, glowClass }: { icon: React.ReactNode, number: string, label: string, glowClass: string }) {
  return (
    <div className={`glass-panel p-8 rounded-[32px] flex flex-col items-center justify-center text-center transition-transform hover:-translate-y-2 relative overflow-hidden border border-border/50 ${glowClass}`}>
      <div className="mb-6 bg-background rounded-2xl p-4 shadow-sm inline-block">{icon}</div>
      <div className="text-5xl font-black font-inter tracking-tight mb-3">{number}</div>
      <div className="text-muted-foreground font-bold text-lg tracking-wide">{label}</div>
    </div>
  );
}
