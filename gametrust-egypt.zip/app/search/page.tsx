"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { ShieldCheck, AlertTriangle, HelpCircle, Loader2, Search as SearchIcon, ArrowLeft } from "lucide-react";
import { collection, query, where, getDocs, or } from "firebase/firestore";
import { db } from "@/lib/firebase";
import Link from "next/link";
import { motion } from "motion/react";

function SearchContent() {
  const searchParams = useSearchParams();
  const q = searchParams.get("q") || "";
  const [loading, setLoading] = useState(true);
  const [results, setResults] = useState<any[]>([]);

  useEffect(() => {
    const fetchResults = async () => {
      setLoading(true);
      if (!q.trim()) {
        setResults([]);
        setLoading(false);
        return;
      }
      
      try {
        const targetsRef = collection(db, "targets");
        // Because a basic "OR" or partial text search in Firestore is hard, 
        // we'll fetch elements matching strictly or use an array-contains on searchTerms.
        // For simplicity and prototype, let's just do a basic query where searchTerms contains the query
        // lowercased or phone number.
        const qLower = q.toLowerCase();
        
        const qQuery = query(
          targetsRef,
          or(
            where("phone", "==", qLower),
            where("searchTerms", "array-contains", qLower)
          )
        );

        const snapshot = await getDocs(qQuery);
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // Also fetch by link just in case
        const qLinkQuery = query(targetsRef, where("link", "==", qLower));
        const linkSnapshot = await getDocs(qLinkQuery);
        linkSnapshot.docs.forEach(doc => {
          if (!data.find(d => d.id === doc.id)) {
            data.push({ id: doc.id, ...doc.data() });
          }
        });

        // If no data, just show the empty state immediately
        if (data.length === 0) {
          setResults([]);
          setLoading(false);
          return;
        }

        setResults(data);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [q]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-32 min-h-screen">
      <Link href="/" className="inline-flex items-center gap-2 mb-8 text-muted-foreground hover:text-foreground transition-colors font-medium">
        <ArrowLeft className="w-4 h-4 rtl:-scale-x-100" />
        <span>رجوع للرئيسية</span>
      </Link>
      
      <div className="mb-12">
        <h1 className="text-3xl font-black mb-2 flex items-center gap-3">
          <SearchIcon className="w-8 h-8 text-primary dark:text-neon-blue" />
          <span>نتائج البحث عن "{q}"</span>
        </h1>
        <p className="text-muted-foreground font-medium">
          تم العثور على {results.length} نتيجة مطابقة.
        </p>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Loader2 className="w-12 h-12 animate-spin text-primary dark:text-neon-blue" />
          <p className="text-muted-foreground font-medium text-lg animate-pulse">جاري البحث في قاعدة البيانات...</p>
        </div>
      ) : results.length > 0 ? (
        <div className="space-y-6">
          {results.map((target, idx) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              key={target.id}
            >
              <TargetCard target={target} />
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 glass-panel rounded-3xl border border-dashed border-border/60">
          <HelpCircle className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">مفيش نتايج!</h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">
            مفيش أي بيانات أو بلاغات عن الرقم أو الصفحة دي حالياً. لو اتنصب عليك منهم، ياريت تقدم بلاغ وتساعد غيرك.
          </p>
          <Link href={`/report?target=${encodeURIComponent(q)}`} className="inline-flex items-center gap-2 bg-primary dark:bg-neon-blue text-white dark:text-black font-bold px-6 py-3 rounded-xl hover:scale-105 transition-transform shadow-[0_0_15px_rgba(37,99,235,0.3)] dark:shadow-[0_0_15px_rgba(0,243,255,0.3)]">
            <AlertTriangle className="w-5 h-5" />
            <span>قدم بلاغ عن الصفحة دي</span>
          </Link>
        </div>
      )}
    </div>
  );
}

export default function SearchPage() {
  return (
    <>
      <Navbar />
      <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><Loader2 className="w-10 h-10 animate-spin text-primary" /></div>}>
        <SearchContent />
      </Suspense>
    </>
  );
}

function TargetCard({ target }: { target: any }) {
  const isHighRisk = target.status === "high_risk";
  const isTrusted = target.status === "trusted";
  
  return (
    <Link href={`/target/${target.id}`} className="block">
      <div className={`glass-panel p-6 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 border-l-4 transition-all hover:scale-[1.01] ${isHighRisk ? 'border-l-destructive glow-warning' : isTrusted ? 'border-l-green-500 hover:glow-secure' : 'border-l-yellow-500'}`}>
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-xl font-bold">{target.name}</h3>
            <span className="text-xs font-bold px-2 py-1 bg-secondary rounded-md uppercase tracking-wider">{target.type}</span>
          </div>
          <div className="flex gap-4 text-sm text-muted-foreground font-medium">
            {target.phone && <span>📞 {target.phone}</span>}
            {target.link && <span className="underline decoration-muted-foreground/30 underline-offset-4">🔗 {new URL(target.link).hostname}</span>}
          </div>
        </div>
        
        <div className="flex items-center gap-6 shrink-0 bg-background/50 p-4 rounded-xl">
          <div className="text-center">
            <div className="text-xs text-muted-foreground font-bold mb-1 uppercase tracking-wider">Score</div>
            <div className={`text-2xl font-black font-inter ${isHighRisk ? 'text-destructive' : isTrusted ? 'text-green-500' : 'text-yellow-500'}`}>
              {target.trustScore}%
            </div>
          </div>
          <div className="w-px h-10 bg-border"></div>
          <div className="text-center w-24">
            <div className="text-xs text-muted-foreground font-bold mb-1 uppercase tracking-wider">الحالة</div>
            <div className={`font-bold ${isHighRisk ? 'text-destructive' : isTrusted ? 'text-green-500' : 'text-yellow-500'}`}>
              {isHighRisk ? "عالي الخطورة" : isTrusted ? "موثوق" : "قيد المراجعة"}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

// Removed mockData
