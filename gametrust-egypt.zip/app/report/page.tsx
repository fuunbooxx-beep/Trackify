"use client";

import { Suspense, useState, useContext } from "react";
import { Navbar } from "@/components/Navbar";
import { AuthContext } from "@/lib/providers";
import { ShieldAlert, Image as ImageIcon, CheckCircle2, AlertCircle } from "lucide-react";
import { useSearchParams, useRouter } from "next/navigation";
import { auth, db, handleFirestoreError, OperationType } from "@/lib/firebase";
import { collection, addDoc, serverTimestamp, doc, setDoc } from "firebase/firestore";
import { signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { motion } from "motion/react";

function ReportContent() {
  const { user, loading } = useContext(AuthContext);
  const searchParams = useSearchParams();
  const router = useRouter();
  
  const [targetName, setTargetName] = useState(searchParams.get("target") || "");
  const [targetPhone, setTargetPhone] = useState("");
  const [targetLink, setTargetLink] = useState("");
  const [category, setCategory] = useState("scam");
  const [description, setDescription] = useState("");
  
  // Fake image upload for UI purposes
  const [images, setImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, new GoogleAuthProvider());
    } catch (error) {
      console.error(error);
    }
  };

  const handleImageStub = () => {
    if (images.length < 3) {
      setImages([...images, `https://picsum.photos/seed/${Date.now()}/400/300`]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!targetName) {
      setErrorMsg("الرجاء إدخال إسم الصفحة أو البائع.");
      return;
    }
    setErrorMsg("");
    setIsSubmitting(true);

    try {
      // Create a target first
      // In a real app we'd search if the target exists, if not create. For simplicity, we just create a new one every time with a random ID or unique link/phone.
      // We will generate an ID based on timestamp
      const targetId = "target_" + Date.now();
      
      await setDoc(doc(db, "targets", targetId), {
        name: targetName,
        type: "page",
        phone: targetPhone,
        link: targetLink,
        status: "reviewing",
        trustScore: 50, // Starting score
        reportCount: 1, // Start with 1, should be updated securely
        searchTerms: [targetName.toLowerCase(), targetPhone, targetLink].filter(Boolean),
        createdAt: Date.now(),
        updatedAt: Date.now()
      });

      // Add the report
      const reportId = "report_" + Date.now();
      await setDoc(doc(db, "reports", reportId), {
        targetId: targetId,
        authorId: user.uid,
        category: category,
        description: description,
        evidenceImages: images,
        status: "pending",
        createdAt: Date.now()
      });

      setSuccess(true);
      setTimeout(() => {
        router.push(`/target/${targetId}`);
      }, 2000);

    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "targets/reports");
      setErrorMsg("حصلت مشكلة أثناء إرسال البلاغ. تأكد من صلاحياتك.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-32 min-h-screen">
      <div className="mb-10 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-destructive/10 text-destructive mb-4">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h1 className="text-3xl md:text-4xl font-black mb-4">تقديم بلاغ جديد</h1>
        <p className="text-muted-foreground font-medium">قدم دليلك وساعدنا نحذر غيرك من النصابين.</p>
      </div>

      {loading ? (
        <div className="text-center">جاري التحميل...</div>
      ) : !user ? (
        <div className="glass-panel p-10 rounded-3xl text-center">
          <AlertCircle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4">لازم تسجل دخول الأول!</h2>
          <p className="text-muted-foreground mb-8">عشان نقدر نتحقق من صحة البلاغات ونمنع السبام، لازم تسجل دخول بحساب جوجل بتاعك.</p>
          <button onClick={handleLogin} className="bg-primary dark:bg-neon-blue text-white dark:text-black font-bold px-8 py-3 rounded-xl hover:scale-105 transition-transform">
            تسجيل الدخول للاستمرار
          </button>
        </div>
      ) : success ? (
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="glass-panel p-10 rounded-3xl text-center border-green-500/30">
          <CheckCircle2 className="w-20 h-20 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">تم استلام بلاغك بنجاح!</h2>
          <p className="text-muted-foreground">جاري تحويلك لصفحة البائع...</p>
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit} className="glass-panel p-6 md:p-10 rounded-3xl space-y-6">
          {errorMsg && (
            <div className="bg-destructive/10 border border-destructive/30 text-destructive p-4 rounded-xl flex items-center gap-3 font-semibold">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="font-bold text-sm uppercase tracking-wider text-muted-foreground">إسم الصفحة / البائع <span className="text-destructive">*</span></label>
              <input 
                type="text" 
                required
                value={targetName}
                onChange={(e) => setTargetName(e.target.value)}
                className="w-full bg-background border border-border p-3 rounded-xl outline-none focus:ring-2 focus:ring-primary dark:focus:ring-neon-blue transition-shadow font-medium"
                placeholder="مثال: Ahmed Store"
              />
            </div>

            <div className="space-y-2">
              <label className="font-bold text-sm uppercase tracking-wider text-muted-foreground">التصنيف <span className="text-destructive">*</span></label>
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-background border border-border p-3 items-center rounded-xl outline-none focus:ring-2 focus:ring-primary dark:focus:ring-neon-blue transition-shadow font-medium h-[50px]"
              >
                <option value="scam">نصب / سرقة حسابات وتتضمن نصب شدات</option>
                <option value="delay">تأخير شديد في التسليم</option>
                <option value="bad_treatment">سوء معاملة / شتيمة</option>
              </select>
            </div>
            
            <div className="space-y-2">
              <label className="font-bold text-sm uppercase tracking-wider text-muted-foreground">رقم الهاتف (اختياري)</label>
              <input 
                type="text"
                value={targetPhone}
                onChange={(e) => setTargetPhone(e.target.value)}
                className="w-full bg-background border border-border p-3 rounded-xl outline-none focus:ring-2 focus:ring-primary dark:focus:ring-neon-blue transition-shadow font-medium text-left dir-ltr placeholder:text-right"
                placeholder="01xxxxxxxxx"
                dir="ltr"
              />
            </div>

            <div className="space-y-2">
              <label className="font-bold text-sm uppercase tracking-wider text-muted-foreground">لينك الصفحة (اختياري)</label>
              <input 
                type="url"
                value={targetLink}
                onChange={(e) => setTargetLink(e.target.value)}
                className="w-full bg-background border border-border p-3 rounded-xl outline-none focus:ring-2 focus:ring-primary dark:focus:ring-neon-blue transition-shadow font-medium text-left dir-ltr placeholder:text-right"
                placeholder="https://facebook.com/..."
                dir="ltr"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="font-bold text-sm uppercase tracking-wider text-muted-foreground">وصف اللي حصل <span className="text-destructive">*</span></label>
            <textarea 
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-background border border-border p-4 rounded-xl outline-none focus:ring-2 focus:ring-primary dark:focus:ring-neon-blue transition-shadow font-medium min-h-[120px] resize-y"
              placeholder="احكي بالتفصيل إيه اللي حصل علشان غيرك يستفيد..."
            ></textarea>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="font-bold text-sm uppercase tracking-wider text-muted-foreground">الأدلة الإسكرين شوت (المصداقية)</label>
              <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded-md">حد أقصى ٣ صور</span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {images.map((img, i) => (
                <div key={i} className="aspect-square rounded-xl bg-secondary overflow-hidden border border-border relative">
                  <img src={img} alt="Evidence" className="w-full h-full object-cover" />
                </div>
              ))}
              
              {images.length < 3 && (
                <button type="button" onClick={handleImageStub} className="aspect-square rounded-xl border-2 border-dashed border-border flex flex-col items-center justify-center text-muted-foreground hover:bg-secondary/50 hover:text-foreground hover:border-primary dark:hover:border-neon-blue transition-all cursor-pointer">
                  <ImageIcon className="w-8 h-8 mb-2 opacity-50" />
                  <span className="text-sm font-bold">رفع صورة</span>
                </button>
              )}
            </div>
            <p className="text-xs text-muted-foreground font-medium">ملاحظة: تأكد من إخفاء معلوماتك الشخصية من الصور قبل رفعها.</p>
          </div>

          <div className="pt-6 border-t border-border mt-8 flex justify-end">
            <button 
              type="submit" 
              disabled={isSubmitting}
              className="bg-primary dark:bg-neon-blue text-white dark:text-black font-bold px-8 py-4 rounded-xl hover:scale-[1.02] transition-transform w-full md:w-auto shadow-[0_0_15px_rgba(37,99,235,0.3)] dark:shadow-[0_0_15px_rgba(0,243,255,0.3)] disabled:opacity-50 disabled:hover:scale-100"
            >
              {isSubmitting ? "جاري الإرسال..." : "تأكيد وإرسال البلاغ"}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

export default function ReportPage() {
  return (
    <>
      <Navbar />
      <Suspense fallback={<div className="min-h-screen items-center justify-center flex">جاري التحميل...</div>}>
        <ReportContent />
      </Suspense>
    </>
  );
}
