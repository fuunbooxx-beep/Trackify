import type { Metadata } from 'next';
import './globals.css';
import { Providers } from '@/lib/providers';
import { Cairo, Inter } from 'next/font/google';

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  variable: '--font-cairo',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'GameTrust Egypt - Detect Scam Gaming Pages & Sellers',
  description: 'A modern platform for detecting scam gaming pages and sellers in Egypt. Check trust scores before buying.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  // Using RTL by default for Egypt region
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning className={`${cairo.variable} ${inter.variable}`}>
      <body className="font-cairo bg-background text-foreground antialiased min-h-screen">
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
