"use client";

import { Navbar } from "@/components/Navbar";

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-32 min-h-screen">
        <h1 className="text-4xl font-black mb-8">عن منصة GameTrust Egypt</h1>
        <div className="glass-panel p-8 rounded-3xl space-y-6 text-lg font-medium leading-relaxed">
          <p>
            منصة GameTrust Egypt هي أول منصة مصرية متخصصة في حماية مجتمع اللاعبين من النصب والاحتيال التجاري.
          </p>
          <p>
            هدفنا الأساسي هو بناء قاعدة بيانات شفافة وموثوقة لكل البائعين وصفحات بيع الحسابات والشدات في مصر. بنسمح لأي مستخدم إنه يقدم بلاغ مدعوم بالإثباتات لو اتعرض للنصب، عشان يحذر غيره ويحمي فلوسهم.
          </p>
          <p>
            بنستخدم نظام (Trust Score) الذكي اللي بيحلل البلاغات وموثوقية المصدر علشان يدي نتيجة عادلة لكل صفحة أو حساب على السوشيال ميديا.
          </p>
          <p className="text-primary dark:text-neon-blue font-bold">
            خلينا إيد واحدة ضد النصب.. راجع قبل ما تشتري، وبلّغ لو اتعرضت للنصب!
          </p>
        </div>
      </div>
    </>
  );
}
