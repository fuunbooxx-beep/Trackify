"use client";

import { Navbar } from "@/components/Navbar";
import { AuthContext } from "@/lib/providers";
import { useContext } from "react";
import { ShieldCheck, User } from "lucide-react";
import { motion } from "motion/react";

export default function ProfilePage() {
  const { user, loading } = useContext(AuthContext);

  if (loading) return <div className="min-h-screen items-center justify-center flex"><Navbar />جاري التحميل...</div>;
  if (!user) return <div className="min-h-screen items-center justify-center flex"><Navbar />لازم تسجل دخول الأول.</div>;

  return (
    <>
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-32 min-h-screen">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-panel p-10 rounded-[32px] text-center mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-bl-full shadow-lg" />
          <img src={user.photoURL || ""} alt="Profile" className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-background" />
          <h1 className="text-3xl font-black mb-1">{user.displayName}</h1>
          <p className="text-muted-foreground font-medium mb-6">{user.email}</p>
          
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary dark:bg-neon-blue/10 dark:text-neon-blue px-4 py-2 rounded-xl font-bold">
            <ShieldCheck className="w-5 h-5" />
            <span>عضو موثوق - مستوى الثقة: متوسط</span>
          </div>
        </motion.div>

        <div className="glass-panel p-8 rounded-3xl">
          <h2 className="text-xl font-bold mb-4">نشاطك وبلاغاتك</h2>
          <p className="text-muted-foreground font-medium">مفيش أي بلاغات مسجلة باسمك حالياً. لو في صفحة نصبت عليك أو واجهت مشكلة في التعامل، تقدر تقدم بلاغ من القائمة فوق.</p>
        </div>
      </div>
    </>
  );
}
